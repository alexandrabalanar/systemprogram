﻿namespace zipunzip
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.OpenFolderBtn = new System.Windows.Forms.Button();
            this.CreateZipBtn = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.UnzipBtn = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.OpenZipBtn = new System.Windows.Forms.Button();
            this.folderBrowserDialog2 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(29, 33);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(256, 20);
            this.textBox1.TabIndex = 0;
            // 
            // OpenFolderBtn
            // 
            this.OpenFolderBtn.Location = new System.Drawing.Point(291, 33);
            this.OpenFolderBtn.Name = "OpenFolderBtn";
            this.OpenFolderBtn.Size = new System.Drawing.Size(25, 20);
            this.OpenFolderBtn.TabIndex = 1;
            this.OpenFolderBtn.Text = "...";
            this.OpenFolderBtn.UseVisualStyleBackColor = true;
            this.OpenFolderBtn.Click += new System.EventHandler(this.OpenFolderBtn_Click);
            // 
            // CreateZipBtn
            // 
            this.CreateZipBtn.Location = new System.Drawing.Point(29, 68);
            this.CreateZipBtn.Name = "CreateZipBtn";
            this.CreateZipBtn.Size = new System.Drawing.Size(287, 23);
            this.CreateZipBtn.TabIndex = 2;
            this.CreateZipBtn.Text = "CREATE ZIP";
            this.CreateZipBtn.UseVisualStyleBackColor = true;
            this.CreateZipBtn.Click += new System.EventHandler(this.CreateZipBtn_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // UnzipBtn
            // 
            this.UnzipBtn.Location = new System.Drawing.Point(29, 159);
            this.UnzipBtn.Name = "UnzipBtn";
            this.UnzipBtn.Size = new System.Drawing.Size(287, 23);
            this.UnzipBtn.TabIndex = 3;
            this.UnzipBtn.Text = "UNZIP";
            this.UnzipBtn.UseVisualStyleBackColor = true;
            this.UnzipBtn.Click += new System.EventHandler(this.UnzipBtn_Click);
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Location = new System.Drawing.Point(29, 123);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(256, 20);
            this.textBox2.TabIndex = 4;
            // 
            // OpenZipBtn
            // 
            this.OpenZipBtn.Location = new System.Drawing.Point(291, 122);
            this.OpenZipBtn.Name = "OpenZipBtn";
            this.OpenZipBtn.Size = new System.Drawing.Size(25, 21);
            this.OpenZipBtn.TabIndex = 5;
            this.OpenZipBtn.Text = "...";
            this.OpenZipBtn.UseVisualStyleBackColor = true;
            this.OpenZipBtn.Click += new System.EventHandler(this.OpenZipBtn_Click);
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Select the folder for archiving:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Select the archive (.ZIP) for unarchiving:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 212);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.OpenZipBtn);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.UnzipBtn);
            this.Controls.Add(this.CreateZipBtn);
            this.Controls.Add(this.OpenFolderBtn);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Zip and UnZip";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button OpenFolderBtn;
        private System.Windows.Forms.Button CreateZipBtn;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button UnzipBtn;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button OpenZipBtn;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog2;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

