﻿using Ionic.Zip;
using System;
using System.Windows.Forms;

namespace zipunzip
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        FolderBrowserDialog bd = new FolderBrowserDialog();
       // OpenFileDialog ofd = new OpenFileDialog();


        private void OpenFolderBtn_Click(object sender, EventArgs e)
        {
            if (bd.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = bd.SelectedPath;
            }
        }

        private void CreateZipBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please select you foolder!");
                return;
            }
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Zip files (*.zip)|*.zip";
            if (textBox1.Text != "" && sfd.ShowDialog() == DialogResult.OK)
            {
                    ZipFile zf = new ZipFile(sfd.FileName);
                zf.AddDirectory(bd.SelectedPath);
                zf.Save();
                MessageBox.Show("Zipping was successful!");
            }
        }

        private void UnzipBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Please select you ZIP archive!");
                return;
            }
            FolderBrowserDialog fd1 = new FolderBrowserDialog();
            
            if (fd1.ShowDialog() == DialogResult.OK)
            {

                //string zep = @"D:\re\re.zip";
                string zep = textBox2.Text;
                // string raz = @"D:\re\me\";
                string raz = fd1.SelectedPath;

                using (ZipFile zip = ZipFile.Read(zep))
                {
                    zip.ExtractAll(raz);
                   
                }
                MessageBox.Show("Unzipping was successful!");
            }
        }

        private void OpenZipBtn_Click(object sender, EventArgs e)
        {
            openFileDialog2.Filter = "Zip files (*.zip)|*.zip";
            DialogResult result = openFileDialog2.ShowDialog();
            
            if (result == DialogResult.OK)
            {
                textBox2.Text = openFileDialog2.FileName;
            }
        }

       
    }
}
    

    

    




